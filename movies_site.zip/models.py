from peewee import (
    DateField, FloatField, ForeignKeyField, IntegerField, Model,
    SqliteDatabase, TextField,
)


database = SqliteDatabase('movies.db')


class UnknownField(object):
    def __init__(self, *_, **__):
        pass


class BaseModel(Model):
    class Meta:
        database = database


class Categories(BaseModel):
    name = TextField()

    class Meta:
        table_name = 'categories'


class Companies(BaseModel):
    name = TextField()

    class Meta:
        table_name = 'companies'


class Keywords(BaseModel):
    name = TextField()

    class Meta:
        table_name = 'keywords'


class Movies(BaseModel):
    budget = IntegerField(null=True)
    homepage = TextField(null=True)
    original_language = TextField()
    original_title = TextField()
    overview = TextField(null=True)
    popularity = TextField(null=True)
    status = TextField(null=True)
    tagline = TextField(null=True)
    title = TextField()
    vote_average = FloatField()
    vote_count = IntegerField()

    class Meta:
        table_name = 'movies'


class Users(BaseModel):
    name = TextField()
    username = TextField(unique=True)
    password = TextField()
    email = TextField(unique=True)
    birthday = DateField()

    class Meta:
        table_name = 'users'


class MoviesCategory(BaseModel):
    category_id = ForeignKeyField(Categories)
    movie_id = ForeignKeyField(Movies)

    class Meta:
        table_name = 'movies_category'


class MoviesUsers(BaseModel):
    user_id = ForeignKeyField(Users)
    movie_id = ForeignKeyField(Movies)

    class Meta:
        table_name = 'movies_users'


class MoviesCompany(BaseModel):
    company_id = ForeignKeyField(Companies)
    movie_id = ForeignKeyField(Movies)

    class Meta:
        table_name = 'movies_company'


class MoviesKeyword(BaseModel):
    keyword_id = ForeignKeyField(Keywords)
    movie_id = ForeignKeyField(Movies)

    class Meta:
        table_name = 'movies_keyword'


TABLES = [
    Categories, Companies, Keywords, Movies, Users,
    MoviesCategory, MoviesUsers, MoviesCompany, MoviesKeyword,
]

with database.connection_context():
    database.create_tables(TABLES, safe=True)
    database.commit()
