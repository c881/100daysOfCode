import sqlite3
from typing import Any, Dict, List

import bcrypt
from flask import Flask, abort, render_template, request
from playhouse.shortcuts import model_to_dict
import peewee

from models import Movies, Users, database


app = Flask(__name__)
app.config.from_pyfile('config.py')


@app.before_request
def _db_connect():
    database.connect()


@app.teardown_request
def _db_close(_):
    if not database.is_closed():
        database.close()


@app.route('/movie/<int:movie_id>')
def show_movie_page(movie_id: int) -> List[Any]:
    # movie = Movies.select().where(Movies.id == movie_id).get()
    try:
        movie = Movies.get_by_id(movie_id)
    except peewee.DoesNotExist:
        abort(404, f'Error: movie {movie_id} does not exists')
    movie_dict = model_to_dict(movie)
    return render_template('movie.j2', **movie_dict)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.j2')

    salt = bcrypt.gensalt(prefix=b'2b', rounds=10)
    unhashed_password = request.form['password'].encode('utf-8')
    hashed_password = bcrypt.hashpw(unhashed_password, salt)
    fields = {
        **request.form,
        'password': hashed_password,
    }
    user = Users(**fields)
    user.save()
    return 'Success!'


@app.route('/')
def hello_world():
    return 'Hello, World!'


if __name__ == '__main__':
    app.run()
